import java.util.Random;

final class Chromosome {
    private static final double MUTATION_RATE = 0.015;
    private long genes;
    private double fitness;

    Chromosome(Chromosome father, Chromosome mother) {
        for (int j = 0; j < 64; ++j) {
            boolean gene = Math.random() < 0.5 ? father.get(j) : mother.get(j);
            if (Math.random() < MUTATION_RATE) gene = !gene;
            set(j, gene);
        }
    }

    Chromosome() {
        genes = new Random().nextLong();
    }

    boolean get(int index) {
        return ((genes >> index) & 1L) == 1L;
    }

    void set(int index, boolean value) {
        if (value) genes |= 1L << index;
        else genes &= ~(1L << index);
        fitness = 0;
    }

    double getFitness() {
        if (fitness == 0) {
            double value = getValue();
            fitness = Math.abs(value * value - 101D);
        }
        return fitness;
    }

    private double getValue() {
        double value = 10D, weight = 0.5;
        for (int i = 63; i >= 0; --i) {
            if (get(i)) value += weight;
            weight /= 2;
        }
        return value;
    }

    @Override
    public String toString() {
        return Double.toString(getValue());
    }
}